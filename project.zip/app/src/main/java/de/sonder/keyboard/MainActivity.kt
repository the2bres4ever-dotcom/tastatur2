package de.sonder.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(48, 48, 48, 48)
        val t = TextView(this)
        t.textSize = 18f
        t.text = "1. Tastatur aktivieren\n2. Tastatur auswählen\n3. Unten testen"
        val a = Button(this)
        a.text = "1. Tastatur aktivieren"
        a.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        val s = Button(this)
        s.text = "2. Tastatur auswählen"
        s.setOnClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        val e = EditText(this)
        e.hint = "3. Hier testen"
        l.addView(t); l.addView(a); l.addView(s); l.addView(e)
        setContentView(l)
    }
}
