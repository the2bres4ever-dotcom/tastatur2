package de.sonder.keyboard

import android.annotation.SuppressLint
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

class KeyboardService : InputMethodService() {
    private val ui = Handler(Looper.getMainLooper())
    private var web: WebView? = null

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreateInputView(): View {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/keyboard.html")
        val h = (320 * resources.displayMetrics.density).toInt()
        w.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
        web = w
        return w
    }

    private fun tap() { web?.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    inner class Bridge {
        @JavascriptInterface
        fun commit(s: String) { ui.post { currentInputConnection?.commitText(s, 1); tap() } }

        @JavascriptInterface
        fun back() {
            ui.post {
                val ic = currentInputConnection
                if (ic != null) {
                    if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1)
                    else ic.deleteSurroundingTextInCodePoints(1, 0)
                    tap()
                }
            }
        }

        @JavascriptInterface
        fun enter() {
            ui.post {
                val ic = currentInputConnection
                if (ic != null) {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                    tap()
                }
            }
        }

        @JavascriptInterface
        fun pickKeyboard() {
            ui.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        }
    }
}
